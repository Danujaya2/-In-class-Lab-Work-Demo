import time
import random
import string
import tkinter as tk
from tkinter import messagebox


# =========================
# BST
# =========================

class BSTNode:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return BSTNode(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        return self.search(root.right, name)

    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if root is None:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left

            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        return root


# =========================
# AVL
# =========================

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        t3 = y.right

        y.right = z
        z.left = t3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    def left_rotate(self, z):
        y = z.right
        t2 = y.left

        y.left = z
        z.right = t2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))

        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)

        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)

        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)

        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)

        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def delete(self, root, name):
        if not root:
            return root

        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            if root.right is None:
                return root.left

            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)

        if root is None:
            return root

        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)

        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)

        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)

        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)

        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)

        return root

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)


# =========================
# RED-BLACK TREE
# =========================

RED = "RED"
BLACK = "BLACK"


class RBNode:
    def __init__(self, name, phone=None, color=RED):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, color=BLACK)
        self.NIL.left = self.NIL
        self.NIL.right = self.NIL
        self.NIL.parent = None
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x

        y.parent = x.parent

        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right
        if x.right != self.NIL:
            x.right.parent = y

        x.parent = y.parent

        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x

        x.right = y
        y.parent = x

    def insert(self, name, phone):
        new_node = RBNode(name, phone, RED)
        new_node.left = self.NIL
        new_node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if new_node.name < current.name:
                current = current.left
            elif new_node.name > current.name:
                current = current.right
            else:
                current.phone = phone
                return

        new_node.parent = parent

        if parent is None:
            self.root = new_node
        elif new_node.name < parent.name:
            parent.left = new_node
        else:
            parent.right = new_node

        self.fix_insert(new_node)

    def fix_insert(self, k):
        while k != self.root and k.parent.color == RED:
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right
                if u.color == RED:
                    k.parent.color = BLACK
                    u.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.right_rotate(k.parent.parent)
            else:
                u = k.parent.parent.left
                if u.color == RED:
                    k.parent.color = BLACK
                    u.color = BLACK
                    k.parent.parent.color = RED
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = BLACK
                    k.parent.parent.color = RED
                    self.left_rotate(k.parent.parent)

        self.root.color = BLACK

    def search(self, node, name):
        if node == self.NIL or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        return self.search(node.right, name)

    def inorder(self, node, result=None):
        if result is None:
            result = []
        if node != self.NIL:
            self.inorder(node.left, result)
            result.append((node.name, node.phone, node.color))
            self.inorder(node.right, result)
        return result

    def transplant(self, u, v):
        if u.parent is None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def minimum(self, node):
        while node.left != self.NIL:
            node = node.left
        return node

    def delete(self, name):
        z = self.search(self.root, name)
        if z == self.NIL:
            return

        y = z
        y_original_color = y.color

        if z.left == self.NIL:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right

            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y

            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

        if y_original_color == BLACK:
            self.fix_delete(x)

    def fix_delete(self, x):
        while x != self.root and x.color == BLACK:
            if x == x.parent.left:
                s = x.parent.right
                if s.color == RED:
                    s.color = BLACK
                    x.parent.color = RED
                    self.left_rotate(x.parent)
                    s = x.parent.right

                if s.left.color == BLACK and s.right.color == BLACK:
                    s.color = RED
                    x = x.parent
                else:
                    if s.right.color == BLACK:
                        s.left.color = BLACK
                        s.color = RED
                        self.right_rotate(s)
                        s = x.parent.right

                    s.color = x.parent.color
                    x.parent.color = BLACK
                    s.right.color = BLACK
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                s = x.parent.left
                if s.color == RED:
                    s.color = BLACK
                    x.parent.color = RED
                    self.right_rotate(x.parent)
                    s = x.parent.left

                if s.right.color == BLACK and s.left.color == BLACK:
                    s.color = RED
                    x = x.parent
                else:
                    if s.left.color == BLACK:
                        s.right.color = BLACK
                        s.color = RED
                        self.left_rotate(s)
                        s = x.parent.left

                    s.color = x.parent.color
                    x.parent.color = BLACK
                    s.left.color = BLACK
                    self.right_rotate(x.parent)
                    x = self.root

        x.color = BLACK


# =========================
# RED-BLACK GUI
# =========================

class RBTreeApp:
    def __init__(self, master):
        self.tree = RedBlackTree()
        self.master = master
        master.title("Red-Black Tree Contact Directory")

        frame = tk.Frame(master)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0, padx=5, pady=5)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5)

        tk.Label(frame, text="Phone:").grid(row=1, column=0, padx=5, pady=5)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1, padx=5, pady=5)

        btn_frame = tk.Frame(master)
        btn_frame.pack(pady=5)

        tk.Button(btn_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(btn_frame, text="Delete", command=self.delete_contact).grid(row=0, column=2, padx=5)
        tk.Button(btn_frame, text="Show All", command=self.show_all).grid(row=0, column=3, padx=5)

        self.output_text = tk.Text(master, height=10, width=60)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(master, width=900, height=420, bg="white")
        self.canvas.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both name and phone.")
            return

        self.tree.insert(name, phone)
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()

        if not name:
            messagebox.showwarning("Input Error", "Please enter name to search.")
            return

        node = self.tree.search(self.tree.root, name)
        self.output_text.delete(1.0, tk.END)

        if node != self.tree.NIL:
            self.output_text.insert(
                tk.END,
                f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\nColor: {node.color}\n"
            )
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def delete_contact(self):
        name = self.name_entry.get().strip()

        if not name:
            messagebox.showwarning("Input Error", "Please enter name to delete.")
            return

        self.tree.delete(name)
        self.clear_entries()
        self.show_all()
        self.draw_tree()

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder(self.tree.root)

        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for name, phone, color in contacts:
                self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}, Color: {color}\n")

    def clear_entries(self):
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root == self.tree.NIL:
            return
        self._draw_node(self.tree.root, 450, 30, 200)

    def _draw_node(self, node, x, y, x_offset):
        if node == self.tree.NIL:
            return

        radius = 20

        if node.left != self.tree.NIL:
            lx = x - x_offset
            ly = y + 70
            self.canvas.create_line(x, y + radius, lx, ly - radius)
            self._draw_node(node.left, lx, ly, max(x_offset // 2, 40))

        if node.right != self.tree.NIL:
            rx = x + x_offset
            ry = y + 70
            self.canvas.create_line(x, y + radius, rx, ry - radius)
            self._draw_node(node.right, rx, ry, max(x_offset // 2, 40))

        fill_color = "red" if node.color == RED else "gray20"
        display_name = node.name if len(node.name) <= 8 else node.name[:8]

        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=fill_color)
        self.canvas.create_text(x, y, text=display_name, fill="white")


# =========================
# BENCHMARK
# =========================

def benchmark_all(n=1000):
    random.seed(42)

    names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    search_names = random.sample(names, n // 2) + ['notfound'] * (n // 2)
    delete_names = random.sample(names, min(100, n))

    bst = BST()
    avl = AVLTree()
    rb = RedBlackTree()

    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert = time.time() - start

    start = time.time()
    found_bst = 0
    for name in search_names:
        if bst.search(bst.root, name):
            found_bst += 1
    bst_search = time.time() - start

    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete = time.time() - start

    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert = time.time() - start

    start = time.time()
    found_avl = 0
    for name in search_names:
        if avl.search(avl.root, name):
            found_avl += 1
    avl_search = time.time() - start

    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete = time.time() - start

    start = time.time()
    for i in range(n):
        rb.insert(names[i], phones[i])
    rb_insert = time.time() - start

    start = time.time()
    found_rb = 0
    for name in search_names:
        if rb.search(rb.root, name) != rb.NIL:
            found_rb += 1
    rb_search = time.time() - start

    start = time.time()
    for name in delete_names:
        rb.delete(name)
    rb_delete = time.time() - start

    print(f"\nBenchmark with {n} entries\n")
    print("Operation      BST         AVL         Red-Black")
    print("-------------------------------------------------")
    print(f"Insert         {bst_insert:.6f}    {avl_insert:.6f}    {rb_insert:.6f}")
    print(f"Search         {bst_search:.6f}    {avl_search:.6f}    {rb_search:.6f}")
    print(f"Delete         {bst_delete:.6f}    {avl_delete:.6f}    {rb_delete:.6f}")
    print("-------------------------------------------------")
    print(f"Found count    {found_bst}         {found_avl}         {found_rb}")


# =========================
# MAIN
# =========================

if __name__ == "__main__":
    print("1. Run Red-Black Tree GUI")
    print("2. Run BST vs AVL vs Red-Black benchmark")
    choice = input("Enter choice (1 or 2): ")

    if choice == "1":
        root = tk.Tk()
        app = RBTreeApp(root)
        root.mainloop()
    elif choice == "2":
        benchmark_all(1000)
    else:
        print("Invalid choice")