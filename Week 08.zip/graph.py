class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}  # Initialize an empty dictionary to store the adjacency list
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []  # Add a new vertex with an empty list of edges

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph: # Check that vertices are present
            # store vertex and weight as a tuple
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed: # In the case of an undirected graph, append in both directions
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if (vertex1, vertex2) in self.weights:
                del self.weights[(vertex1, vertex2)]

        if not self.directed:
            if vertex2 in self.graph and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)
                if (vertex2, vertex1) in self.weights:
                    del self.weights[(vertex2, vertex1)]

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]

            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)

            keys_to_delete = []
            for edge in self.weights:
                if vertex in edge:
                    keys_to_delete.append(edge)

            for key in keys_to_delete:
                del self.weights[key]

    def print_graph(self):
        for vertex in self.graph:
            print(vertex, "->", self.graph[vertex])

    def bfs(self, start_vertex):
        if start_vertex not in self.graph:
            return []

        visited = []
        queue = [start_vertex]

        while queue:
            vertex = queue.pop(0)

            if vertex not in visited:
                visited.append(vertex)

                for neighbour in self.graph[vertex]:
                    if neighbour not in visited and neighbour not in queue:
                        queue.append(neighbour)

        return visited
    
    def dfs(self, start_vertex):
        if start_vertex not in self.graph:
            return []

        visited = []
        stack = [start_vertex]

        while stack:
            vertex = stack.pop()

            if vertex not in visited:
                visited.append(vertex)

                for neighbour in reversed(self.graph[vertex]):
                    if neighbour not in visited:
                        stack.append(neighbour)

        return visited
    
    def has_undirected_cycle(self):
        visited = set()

        def dfs_cycle(vertex, parent):
            visited.add(vertex)

            for neighbour in self.graph[vertex]:
                if neighbour not in visited:
                    if dfs_cycle(neighbour, vertex):
                        return True
                elif neighbour != parent:
                    return True

            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs_cycle(vertex, None):
                    return True

        return False
    
    def print_graph(self):
     for vertex in self.graph:
        if self.weighted:
            connections = []
            for neighbour in self.graph[vertex]:
                weight = self.weights.get((vertex, neighbour), 0)
                connections.append(f"{neighbour}({weight})")
            print(vertex, "->", connections)
        else:
            print(vertex, "->", self.graph[vertex])
    