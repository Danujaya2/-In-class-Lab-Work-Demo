from graph import Graph

# Basic undirected graph tests
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')

print("After adding vertices:")
g.print_graph()
print()

g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')

print("After adding edges:")
g.print_graph()
print()

g.remove_edge('A', 'B')
print("After removing edge A-B:")
g.print_graph()
print()

g.remove_vertex('D')
print("After removing vertex D:")
g.print_graph()
print()


# Directed graph tests
g2 = Graph(directed=True)
g2.add_vertex('A')
g2.add_vertex('B')
g2.add_vertex('C')
g2.add_vertex('D')

g2.add_edge('A', 'B')
g2.add_edge('B', 'C')
g2.add_edge('C', 'D')

print("Directed graph:")
g2.print_graph()
print()


g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')
g.add_vertex('D')
g.add_vertex('E')

g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
g.add_edge('C', 'E')

print("Graph:")
g.print_graph()
print()

print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

# DFS on the same graph
print("DFS starting from vertex 'A':")
visited_dfs = g.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

#cycle detection in undirected graphs
# Create graph with a cycle
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # Closing the cycle

print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())


# Create graph without a cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')
print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())

# Create weighted directed graph
wg = Graph(directed=True, weighted=True)

for v in ['A', 'B', 'C']:
    wg.add_vertex(v)

wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)

print("Weighted Directed Graph:")
wg.print_graph()
